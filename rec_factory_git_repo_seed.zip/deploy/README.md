# Single‑VM Deployment
- Copy repo to VM, create `.env` from `deploy/.env.prod.example`, and run:
```
docker compose -f docker-compose.yml -f deploy/docker-compose.prod.yml up -d --build
API_BASE=http://localhost:8000 ./scripts/smoke.sh
```
