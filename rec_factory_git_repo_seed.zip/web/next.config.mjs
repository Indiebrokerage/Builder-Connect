export default { experimental: { appDir: true } }
